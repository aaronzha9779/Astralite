import { getRankForLevel } from '../data/ranks'
import { getLevelFromXp } from './xp'

export function getHabitMaturity(totalXp: number) {
  const m = getLevelFromXp(totalXp)
  return {
    level: m.level,
    rank: getRankForLevel(m.level),
    minutes: m.current,
    minutesToNext: m.toNext,
    percent: m.percent,
  }
}
