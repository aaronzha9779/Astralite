let audioContext: AudioContext | null = null

function getContext(): AudioContext | null {
  const AudioContextCtor = window.AudioContext || (window as typeof window & {
    webkitAudioContext?: typeof AudioContext
  }).webkitAudioContext

  if (!AudioContextCtor) return null
  if (!audioContext) audioContext = new AudioContextCtor()
  if (audioContext.state === 'suspended') {
    void audioContext.resume().catch(() => {})
  }
  return audioContext
}

function playTone(
  ctx: AudioContext,
  frequency: number,
  startAt: number,
  duration: number,
  volume: number,
) {
  const oscillator = ctx.createOscillator()
  const gain = ctx.createGain()
  oscillator.type = 'triangle'
  oscillator.frequency.setValueAtTime(frequency, startAt)
  oscillator.connect(gain)
  gain.connect(ctx.destination)

  gain.gain.setValueAtTime(0.0001, startAt)
  gain.gain.exponentialRampToValueAtTime(volume, startAt + 0.02)
  gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration)

  oscillator.start(startAt)
  oscillator.stop(startAt + duration)
}

export function playCompletionChime() {
  const ctx = getContext()
  if (!ctx) return
  const now = ctx.currentTime
  playTone(ctx, 784, now, 0.18, 0.05)
  playTone(ctx, 988, now + 0.1, 0.22, 0.045)
}

export function playRewardChime() {
  const ctx = getContext()
  if (!ctx) return
  const now = ctx.currentTime
  playTone(ctx, 784, now, 0.18, 0.04)
  playTone(ctx, 1047, now + 0.09, 0.2, 0.045)
  playTone(ctx, 1319, now + 0.18, 0.28, 0.05)
}
