import { getRankForLevel } from '../data/ranks'
import type { Habit, ProfileData, UserProfile } from '../types'

export type XpBreakdown = {
  base: number
  bonus: number
  total: number
  bonusLabel?: string
}

export const XP_PER_LEVEL = 250

export function getHabitWeight(habit: Habit): number {
  void habit
  return 1
}

export function calculateTimeXp(
  habit: Habit,
  minutes: number,
  rate = 0.6,
): XpBreakdown {
  void habit
  const base = getFlatTimeXp(minutes, rate)
  return {
    base,
    bonus: 0,
    total: base,
  }
}

export function calculateCompletionXp(
  habit: Habit,
  baseXp = 15,
): XpBreakdown {
  void habit
  const base = getFlatCompletionXp(baseXp)
  return {
    base,
    bonus: 0,
    total: base,
  }
}

export function getFlatTimeXp(minutes: number, rate = 0.6): number {
  return Math.max(1, Math.round(minutes * Math.max(0, rate)))
}

export function getFlatCompletionXp(baseXp = 15): number {
  return Math.max(1, Math.round(baseXp))
}

export function getLevelFromXp(totalXp: number) {
  const level = Math.floor(Math.max(0, totalXp) / XP_PER_LEVEL) + 1
  const current = Math.max(0, totalXp) % XP_PER_LEVEL
  return {
    level,
    current,
    toNext: XP_PER_LEVEL,
    percent: Math.round((current / XP_PER_LEVEL) * 100),
  }
}

export function getAvailableXp(profile: ProfileData): number {
  return Math.max(0, (profile.totalXp ?? 0) - (profile.spentXp ?? 0))
}

export function toUserProfile(profile: ProfileData): UserProfile {
  const { level, current, toNext } = getLevelFromXp(profile.totalXp ?? 0)
  return {
    name: profile.name,
    handle: profile.handle,
    avatarUrl: profile.avatarUrl,
    accentColor: profile.accentColor,
    streakSymbol: profile.streakSymbol,
    streakSymbolImageUrl: profile.streakSymbolImageUrl ?? null,
    rank: getRankForLevel(level),
    level,
    progressXp: current,
    progressToNext: toNext,
    availableMinutes: Math.max(
      0,
      profile.totalMinutes - (profile.spentMinutes ?? 0),
    ),
    totalMinutes: profile.totalMinutes,
    availableXp: getAvailableXp(profile),
    totalXp: profile.totalXp ?? 0,
  }
}
