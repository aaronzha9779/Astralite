export type NavItem = {
  id: string
  label: string
}

export type UserProfile = {
  name: string
  handle: string
  avatarUrl: string | null
  accentColor: string
  streakSymbol: string
  streakSymbolImageUrl: string | null
  rank: string
  level: number
  /** XP progress inside the current level. */
  progressXp: number
  progressToNext: number
  availableMinutes: number
  totalMinutes: number
  /** Spendable XP for the shop and account progression. */
  availableXp: number
  totalXp: number
}

export type HabitCategory = 'daily' | 'hobby' | 'habit'

export type Habit = {
  id: string
  name: string
  category: HabitCategory
  streak: number
  doneToday: boolean
  lastCompletedDate: string | null
  createdAt: string
  /** Lifetime minutes logged for this item. */
  totalMinutes: number
  /** 1 (easy) – 5 (hard); affects baseline XP. */
  difficulty: number
  /** 1 (low) – 5 (high); affects baseline XP. */
  priority: number
  /** Other habits/hobbies that complete together with this one. */
  linkedHabitIds: string[]
  tags: string[]
}

export type WeeklyTask = {
  id: string
  name: string
  done: boolean
}

export type DashboardPrefs = {
  quotes: string[]
  dailyGoal: string
  checksOpen: boolean
  weeklyOpen: boolean
  collapsedCategories: Partial<Record<HabitCategory, boolean>>
  /** Index into quotes when showing a fixed quote; null = random on load. */
  activeQuoteIndex: number | null
}

export type AppPreferences = {
  itemCompletionXp: Record<string, number>
  itemBaseMinutes: Record<string, number>
}

export type CompletionRecord = {
  id: string
  habitId: string
  habitName: string
  date: string
  completedAt: string
}

export type TimeRecord = {
  id: string
  habitId: string
  habitName: string
  date: string
  minutes: number
  source: 'timer' | 'manual'
}

export type PurchasedReward = {
  rewardId: string
  purchasedAt: string
}

export type ProfileData = {
  name: string
  handle: string
  avatarUrl: string | null
  accentColor: string
  streakSymbol: string
  streakSymbolImageUrl: string | null
  totalMinutes: number
  spentMinutes: number
  totalXp: number
  spentXp: number
}

export type AppState = {
  habits: Habit[]
  checks: WeeklyTask[]
  weeklyTasks: WeeklyTask[]
  dashboard: DashboardPrefs
  profile: ProfileData
  preferences: AppPreferences
  rewards: Reward[]
  lastActiveDate: string
  completions: CompletionRecord[]
  timeRecords: TimeRecord[]
  purchasedRewards: PurchasedReward[]
}

export type AccountSummary = {
  id: string
  name: string
  handle: string
  lastUpdatedAt: string
}

export type DashboardStat = {
  id: string
  label: string
  value: string
}

export type Reward = {
  id: string
  name: string
  description: string
  cost: number
  emoji: string
  imageUrl?: string | null
  oneTime: boolean
}

export type HeatmapDay = {
  date: string
  count: number
  level: 0 | 1 | 2 | 3 | 4
}

export type HabitTimeStats = {
  todayMinutes: number
  weekMinutes: number
  totalMinutes: number
}
