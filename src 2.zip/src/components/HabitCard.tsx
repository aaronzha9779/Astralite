import { useState } from 'react'
import { playCompletionChime } from '../lib/audio'
import type { Habit } from '../types'
import './HabitCard.css'

type HabitCardProps = {
  habit: Habit
  streakSymbol: string
  streakSymbolImageUrl: string | null
  completionXp: number
  linkedNames?: string[]
  onToggle: (id: string) => void
}

export function HabitCard({
  habit,
  streakSymbol,
  streakSymbolImageUrl,
  completionXp,
  linkedNames = [],
  onToggle,
}: HabitCardProps) {
  const [showXp, setShowXp] = useState(false)
  const displayStreakSymbol = habit.streak > 30 ? '❤️‍🔥' : streakSymbol

  function handleToggle() {
    const wasIncomplete = !habit.doneToday

    onToggle(habit.id)

    if (wasIncomplete) {
      playCompletionChime()
      setShowXp(true)
      setTimeout(() => setShowXp(false), 900)
    }
  }

  return (
    <li className={`habit-card${habit.category === 'hobby' ? ' habit-card--hobby' : ''}`}>
      <button
        type="button"
        className={`habit-card__btn${habit.doneToday ? ' habit-card__btn--done' : ''}`}
        onClick={handleToggle}
        aria-pressed={habit.doneToday}
      >
        <span
          className={`habit-card__check${habit.doneToday ? ' habit-card__check--done' : ''}`}
          aria-hidden="true"
        />
        <span className="habit-card__body">
          <span className="habit-card__name">{habit.name}</span>
          {linkedNames.length > 0 ? (
            <span className="habit-card__linked" title="Linked completions">
              ⇄ {linkedNames.join(', ')}
            </span>
          ) : null}
        </span>
        {habit.streak > 0 ? (
          <span className="habit-card__streak" title={`${habit.streak} day streak`}>
            {habit.streak > 30 || !streakSymbolImageUrl ? (
              <span className="habit-card__streak-fire" aria-hidden="true">
                {displayStreakSymbol}
              </span>
            ) : (
              <img
                className="habit-card__streak-image"
                src={streakSymbolImageUrl}
                alt=""
              />
            )}
            <span className="habit-card__streak-count">{habit.streak}</span>
          </span>
        ) : (
          <span className="habit-card__meta">No streak</span>
        )}
        {showXp ? <span className="habit-card__xp-pop">+{completionXp} XP</span> : null}
      </button>
    </li>
  )
}
